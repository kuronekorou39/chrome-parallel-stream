// 配信サイトが iframe 内(= multiview のタイル)で読まれたときに動く content script。
// 役割:
//   1. 起動直後だけフレーム内の <video> を全ミュート(轟音防止)。
//   2. 親(multiview)からの「音量設定」指示で全 <video> の volume と muted を維持する
//      (音はスライダーが所有。スマホ縦積みではプレイヤーUIに触れないため、これが唯一の音導線)。
//   3. Twitch のみ: シアターモードを1回 click して player を最大化。
// 最上位タブ(通常閲覧)では何もしない。

// 自分の枠(multiview)の中でだけ動かす。「iframe の中かどうか」だけで判定すると、無関係なサイトが
// 配信ページを埋め込んでいる場合にもこのスクリプトが動き、フレームの URL やポインタのスクリーン座標を
// その相手サイトへ postMessage で渡してしまう(通常はクロスオリジンで取得できない情報)。
// 最上位の祖先オリジンが multiview のページ(ホスト版 or 拡張ページ)のときだけ動かす。
// なお他拡張のページ内フレームには他拡張の content script は注入されないため、
// 祖先が chrome-extension:// なら、それは自分の拡張ページだと判断してよい。
const MV_HOST_ORIGIN = 'https://kuronekorou39.github.io';
function mvInOwnFrame() {
  try {
    const a = location.ancestorOrigins;
    if (!a || a.length === 0) return false;
    const top = a[a.length - 1];
    return top === MV_HOST_ORIGIN || top.indexOf('chrome-extension://') === 0;
  } catch (e) {
    return false;
  }
}

(function streamControl() {
  if (window.top === window.self) return; // iframe 内のみ動作
  if (!mvInOwnFrame()) return; // multiview の枠でないなら何もしない
  const MAGIC = '__multiviewControl';
  const host = location.hostname;

  // ---- 音声 ----
  // 親(multiview.html)からの「この枠の実音量」指示(value: 0〜1 = 枠ごと音量 × マスタ)。
  // 枠ごと音量とマスタの掛け算は親側で済ませて effective を送ってくるので、ここはそれを全 video に
  // 当てて維持するだけ。Twitch等は内蔵スライダーが video.volume を動かさない(Web Audio 経由)ため、
  // 確実に効く video.volume をこちらで当て続ける(= 親の指定値を強制)。
  // muted もスライダーが所有する(>0 で解除 / 0 でミュート)。スマホの縦積みではシールドにより
  // プレイヤーUIへ触れないため、親のスライダーだけで音が出る/消えることを保証する。
  // 「1つだけ聞く」は他の枠の音量を 0 にして行う(プレイヤー自前のミュートには頼らない)。
  let mvVolume = null; // null = まだ未受信。この間は鳴らさない(轟音防止)
  // 自分で当てた直後の volumechange は無視する間隔。
  // volumechange を合図に即座に当て直すと、サイト側も自分の記憶値へ戻そうとするため押し合いになり、
  // 1秒間に何百回も書き合って枠が重くなる。同一サイトの枠は1プロセスに同居するので、1枠で起きると
  // 同居する枠まで一斉にカクつく(実際に発生)。ここで間隔を空け、押し合っても毎秒数回までに抑える。
  // 取りこぼしても下の1秒ポーリングが必ず拾うので、音量が狂ったままにはならない。
  const VOL_SETTLE_MS = 350;
  function applyVolTo(v, viaVolumeChange) {
    if (!v || v.tagName !== 'VIDEO') return;
    const now = Date.now();
    if (viaVolumeChange && v.mvVolAt && now - v.mvVolAt < VOL_SETTLE_MS) return; // 自分が書いた反響 or 押し合い
    try {
      if (mvVolume === null) { // 音量が決まるまでは無音を保つ
        if (!v.muted) { v.muted = true; v.mvVolAt = now; }
        return;
      }
      // 音量を先に当ててからミュートを解く。逆にすると、解いた瞬間だけサイトの記憶値
      // (たいてい最大)で鳴ってしまう。
      let wrote = false;
      if (Math.abs(v.volume - mvVolume) > 0.005) { v.volume = mvVolume; wrote = true; }
      const wantMuted = mvVolume <= 0;
      if (v.muted !== wantMuted) { v.muted = wantMuted; wrote = true; }
      if (wrote) v.mvVolAt = now; // 書いた時だけ記録(書いていないなら反響も起きない)
    } catch (err) { /* noop */ }
  }
  function applyVol() {
    document.querySelectorAll('video').forEach(applyVolTo);
  }
  applyVol(); // 既にある video(注入前に用意されていた分)を先に押さえる

  // ---- 枠内シアター(スマホでは常時自動) ----
  // 視聴ページではページ内の主要 <video> を枠いっぱいに固定表示し、ページスクロールを封じる。
  // 大きな video が無いページ(一覧など)では何もしないので、ブラウズはそのまま。
  // 下の「シアターモード click」はデスクトップ版Twitch専用(モバイル版にはボタンが無い)ため、
  // モバイルはこちらが担当する。⛶全画面中は親から suspend が来て、素のサイト操作に戻る。
  // シアターの有効化は親(multiview)主導。親はスタックモード(スマホ縦積み)かどうかを確実に
  // 知っているため、iframe 内の pointer:coarse 判定(環境で不安定)には頼らない。
  let theaterOn = false; // 親から set-theater-enabled が来たら true
  let theaterSuspended = false; // ⛶全画面中の一時停止
  let theaterEl = null;   // シアター中の対象 video / iframe
  let theaterWrap = null; // 対象 video を入れる全画面オーバーレイ(html 直下=transform 付き祖先の外)
  let theaterHome = null; // 対象の元の位置 { parent, next }。解除時に戻す
  let theaterReported = null; // 親へ通知済みの状態(枠バッジ診断用)
  // state: 'on'=動画を固定中 / 'searching'=有効だが主映像が見つからない / 'off'=無効。
  function reportTheater(state) {
    if (theaterReported === state) return;
    theaterReported = state;
    try {
      window.parent.postMessage({ [MAGIC]: true, type: 'theater-state', state }, '*');
    } catch (e) { /* noop */ }
  }
  // 固定対象 = ページ内の主要メディア。まず大きな <video>、無ければ「プレイヤーらしい iframe」
  // (モバイル版サイトは動画を子フレームに置く構造があり、外側ページに video が無いため)。
  function findMainMedia() {
    let best = null;
    let bestArea = 0;
    document.querySelectorAll('video').forEach((v) => {
      const r = v.getBoundingClientRect();
      if (r.width >= window.innerWidth * 0.5 && r.width * r.height > bestArea) {
        best = v;
        bestArea = r.width * r.height;
      }
    });
    if (best) return best;
    document.querySelectorAll('iframe').forEach((f) => {
      const src = f.getAttribute('src') || '';
      const allow = f.getAttribute('allow') || '';
      if (!(/player\.|\/embed\/|ivs\./i.test(src) || /autoplay/i.test(allow))) return; // プレイヤー風のみ
      const r = f.getBoundingClientRect();
      if (r.width >= window.innerWidth * 0.5 && r.height >= window.innerHeight * 0.2 && r.width * r.height > bestArea) {
        best = f;
        bestArea = r.width * r.height;
      }
    });
    return best;
  }
  // 対象を元の位置・スタイルへ戻す(オーバーレイは撤去)。
  function restoreTheaterEl() {
    if (theaterEl) {
      ['position', 'left', 'top', 'width', 'height', 'object-fit', 'z-index', 'background', 'border']
        .forEach((p) => theaterEl.style.removeProperty(p));
      if (theaterHome && theaterHome.parent && theaterHome.parent.isConnected) {
        try {
          if (theaterHome.next && theaterHome.next.parentNode === theaterHome.parent) {
            theaterHome.parent.insertBefore(theaterEl, theaterHome.next);
          } else {
            theaterHome.parent.appendChild(theaterEl);
          }
        } catch (e) { /* noop */ }
      }
    }
    if (theaterWrap) { try { theaterWrap.remove(); } catch (e) { /* noop */ } theaterWrap = null; }
    theaterEl = null;
    theaterHome = null;
  }
  function clearTheaterAll() {
    restoreTheaterEl();
    document.documentElement.style.removeProperty('overflow');
    if (document.body) document.body.style.removeProperty('overflow');
    reportTheater(theaterOn && !theaterSuspended ? 'searching' : 'off');
  }
  function fillStyle(el) {
    const s = el.style;
    s.setProperty('width', '100%', 'important');
    s.setProperty('height', '100%', 'important');
    s.setProperty('max-width', 'none', 'important');
    s.setProperty('max-height', 'none', 'important');
    s.setProperty('object-fit', 'contain', 'important');
    s.setProperty('background', '#000', 'important');
    s.setProperty('border', '0', 'important');
  }
  function applyTheater() {
    if (!theaterOn || theaterSuspended) return;
    const m = findMainMedia();
    if (!m) { clearTheaterAll(); return; } // 視聴ページ以外では何もしない

    if (theaterEl !== m) {
      if (theaterEl) restoreTheaterEl(); // 対象が替わった(SPA遷移/プレイヤー再生成)
      theaterEl = m;
      theaterHome = { parent: m.parentNode, next: m.nextSibling };
    }

    if (m.tagName === 'VIDEO') {
      // <video> はオーバーレイ(html 直下)へ移動する。これで transform 付き祖先があっても
      // 確実に全画面化でき、ページのどこがスクロールしても上を覆う。再生は途切れない(MSE 維持)。
      if (!theaterWrap || !theaterWrap.isConnected) {
        theaterWrap = document.createElement('div');
        theaterWrap.setAttribute('data-mv-theater', '');
        theaterWrap.style.cssText =
          'position:fixed;left:0;top:0;width:100vw;height:100vh;z-index:2147483647;background:#000;margin:0;padding:0;';
        document.documentElement.appendChild(theaterWrap);
      }
      if (m.parentNode !== theaterWrap) theaterWrap.appendChild(m);
      fillStyle(m);
    } else {
      // <iframe> は DOM 移動するとリロードされるため、その場で固定する。
      const s = m.style;
      s.setProperty('position', 'fixed', 'important');
      s.setProperty('left', '0', 'important');
      s.setProperty('top', '0', 'important');
      s.setProperty('width', '100vw', 'important');
      s.setProperty('height', '100vh', 'important');
      s.setProperty('z-index', '2147483647', 'important');
      s.setProperty('background', '#000', 'important');
      s.setProperty('border', '0', 'important');
    }
    // スクロールは html と body の両方で封じる(サイトによりスクロール主体が異なるため)。
    document.documentElement.style.setProperty('overflow', 'hidden', 'important');
    if (document.body) document.body.style.setProperty('overflow', 'hidden', 'important');
    reportTheater('on');
  }
  // サイト側の上書きや SPA 遷移に追従して当て直す(OFF の間は何もしない)。
  setInterval(applyTheater, 1000);

  window.addEventListener('message', (e) => {
    if (e.source !== window.parent) return; // 親以外からの偽装を弾く
    const d = e.data;
    if (!d || d[MAGIC] !== true) return;
    if (d.type === 'set-volume') {
      mvVolume = Math.max(0, Math.min(1, Number(d.value)));
      applyVol();
    } else if (d.type === 'set-theater-enabled') {
      // 親(スタックモード)からのシアター有効/無効。
      theaterOn = d.value === true;
      if (theaterOn) applyTheater();
      else clearTheaterAll();
    } else if (d.type === 'set-theater-suspend') {
      // ⛶全画面の間はシアターを止め、素のサイトを操作できるようにする(解除で自動復帰)。
      theaterSuspended = d.value === true;
      if (theaterSuspended) clearTheaterAll();
      else applyTheater();
    } else if (d.type === 'set-danmaku-enabled') {
      // 親(multiview)からの弾幕 ON/OFF。ON の間だけチャットDOMを監視して新着コメントを親へ送る。
      danmakuSetEnabled(d.value === true);
    }
  });

  // 起動時に親へ挨拶し、現在のシアター設定(有効/全画面中)を送り返してもらう。
  // content script 注入と親のフレーム load イベントのすれ違いで設定を取りこぼさないため。
  try {
    window.parent.postMessage({ [MAGIC]: true, type: 'frame-hello' }, '*');
  } catch (e) { /* noop */ }

  // 再生が始まる瞬間・サイトが音量を書き換えた瞬間に、その場で当て直す。
  // これが無いと「枠を足すたび、最初だけ大音量で鳴って、そのあと落ち着く」になる。プレイヤーは
  // 自分の記憶値(たいてい最大)を video.volume へ書き戻すので、下の1秒ポーリングまでの最大1秒間、
  // そのままの音量で鳴ってしまうため。以前は YouTube だけを対象にしていたが、Twitch でも同じことが
  // 起きていた(こちらは埋め込みが muted で始まるぶん、ミュートを解いた直後に鳴る)。
  // volumechange の再帰は起きない(差が 0.005 以下なら書かないのでその場で収束する)。
  // 音量/ミュートを当てるだけで play() は呼ばないので、再生ループや churn も起こさない。
  // 再生が始まる契機は素直に当てる(何度も連続しない)。canplay は入れない。バッファリングのたびに
  // 飛んでくるので、回線が細ったときに当て直しが増えて悪化する側に効く。
  ['loadedmetadata', 'play', 'playing'].forEach((ev) =>
    document.addEventListener(ev, (e) => applyVolTo(e.target), true)); // capture=非バブルのメディアイベントも拾う
  // サイト側の書き換えへの追従だけは押し合いになりうるので、上の VOL_SETTLE_MS で間隔を空ける。
  document.addEventListener('volumechange', (e) => applyVolTo(e.target, true), true);
  // 取りこぼしの保険。イベントの来ない経路(プレイヤーの作り直し等)や、注入前から再生していた
  // video のために、遅めの周期で当て直し続ける。
  // (枠ごと音量は 🎨 パネルで操作する設計なので、これで取り違え・戻し問題は起きない)
  setInterval(applyVol, 1000);

  // ---- 長押し → 親へ「このタイルを掴んだ」を中継(縦積みのドラッグ並び替え用) ----
  // サイト内の通常タップ・クリック・スクロールには一切干渉しない(静止 LP_MS で発火、動けば不成立)。
  // 座標は screen 系で送る(ドラッグでタイルごと iframe が動いても screen 座標はぶれないため)。
  // しきい値は親(multiview.js)の LONG_PRESS_MS / LONG_PRESS_SLOP と感覚を合わせること。
  const LP_MS = 450;
  const LP_SLOP = 10;
  let lpTimer = null;
  let lpDown = null; // { sx, sy, cx, cy } 押下時の screen / クライアント座標
  let lpDragging = false;
  let lpEndedAt = 0; // ドラッグ直後の click 誤発火(リンク踏み)抑止用
  let rmbDown = null; // 右ボタンのドラッグ用(マウスのみ)。押下時の screen 座標。動かしたら即つかむ=長押し不要
  let lpPid = null;   // ドラッグ中のポインタID(キャプチャの解放に使う)
  const post = (type, extra) => {
    try {
      window.parent.postMessage(Object.assign({ [MAGIC]: true, type }, extra || {}), '*');
    } catch (e) { /* noop */ }
  };

  // ドラッグ開始時にこの文書でポインタを捕捉する。捕捉しないと、離した瞬間にカーソルが
  // このフレームの外(枠の外や、サイト内の入れ子 iframe の上)にあると pointerup が届かず、
  // lpDragging が true のまま残る。そうなると selectstart を抑止し続けるので、文字選択も
  // 入力欄へのフォーカスもできなくなり、親へ tile-drag-end も飛ばないので枠が掴まれたままになる。
  const capturePointer = (pid) => {
    lpPid = pid;
    try { document.documentElement.setPointerCapture(pid); } catch (e) { /* noop */ }
  };
  // 枠の移動(長押し / 右ドラッグ)を扱うのは、multiview の直下のフレームだけにする。
  // サイト内の入れ子フレーム(YouTube の live_chat 等)でも動かすと、そこでの押下が長押し判定に
  // 入って選択を抑止してしまう。しかも post 先は multiview ではなくサイト自身なので意味も無い。
  const isDirectTile = window.parent === window.top;

  // 入力欄の上では移動操作を始めない。押している間 selectstart を抑止するため、
  // contenteditable ではキャレットを置けなくなり、文字が打てなくなる
  // (YouTube ライブのチャット入力がこれ。<input> は focus が別扱いなので影響が出にくい)。
  const isEditable = (el) => {
    try {
      return !!(el && el.closest && el.closest('input, textarea, select, [contenteditable=""], [contenteditable="true"]'));
    } catch (e) {
      return false;
    }
  };

  window.addEventListener('pointerdown', (e) => {
    if (!isDirectTile || isEditable(e.target)) return;
    if (e.pointerType === 'mouse' && e.button === 2) { // 右ボタン: 動かせば即つかんで移動(長押し不要)。右クリックメニューは出さない。
      rmbDown = { sx: e.screenX, sy: e.screenY };
      lpDragging = false;
      post('tile-raise'); // ドラッグ前でも、右クリックした枠を即座に最前面へ
      return;
    }
    if (!e.isPrimary || (e.pointerType === 'mouse' && e.button !== 0)) return;
    if (e.shiftKey) { // Shift+クリック = 親へ「この枠を複数選択にトグル」(サイトには通さない)
      try { e.preventDefault(); } catch (_) { /* noop */ }
      post('tile-shift-click');
      return; // 長押し検知は始めない
    }
    lpDown = { sx: e.screenX, sy: e.screenY, cx: e.clientX, cy: e.clientY };
    lpDragging = false;
    clearTimeout(lpTimer);
    const pid = e.pointerId;
    lpTimer = setTimeout(() => {
      if (!lpDown) return;
      lpDragging = true;
      capturePointer(pid);
      post('tile-drag-start', lpDown);
    }, LP_MS);
  }, true); // capture: サイト側が stopPropagation しても拾う
  window.addEventListener('pointermove', (e) => {
    if (!e.isPrimary) return;
    // 右ボタンを押したまま動かしたら、その時点でドラッグ開始(現在位置を始点にしてジャンプを防ぐ)。
    if (rmbDown && !lpDragging && (Math.abs(e.screenX - rmbDown.sx) > LP_SLOP || Math.abs(e.screenY - rmbDown.sy) > LP_SLOP)) {
      lpDragging = true;
      capturePointer(e.pointerId);
      post('tile-drag-start', { sx: e.screenX, sy: e.screenY, cx: e.clientX, cy: e.clientY });
    }
    if (lpDragging) {
      post('tile-drag-move', { sx: e.screenX, sy: e.screenY });
      return;
    }
    if (lpDown && (Math.abs(e.screenX - lpDown.sx) > LP_SLOP || Math.abs(e.screenY - lpDown.sy) > LP_SLOP)) {
      clearTimeout(lpTimer); // 動いた → スクロール/通常操作なので長押し不成立
      lpDown = null;
    }
  }, true);
  const lpEnd = () => {
    clearTimeout(lpTimer);
    lpDown = null;
    rmbDown = null;
    if (lpPid !== null) {
      try { document.documentElement.releasePointerCapture(lpPid); } catch (e) { /* 既に解放済み */ }
      lpPid = null;
    }
    if (lpDragging) {
      lpDragging = false;
      lpEndedAt = Date.now();
      post('tile-drag-end');
    }
  };
  window.addEventListener('pointerup', lpEnd, true);
  window.addEventListener('pointercancel', lpEnd, true);
  window.addEventListener('lostpointercapture', lpEnd, true); // 捕捉を奪われた場合も終了扱いにする
  // 最後の保険。何らかの理由でポインタイベントが途切れても、抑止状態を残さない。
  // ここが残ると文字選択も入力欄へのフォーカスもできなくなるため、必ず解除する。
  // blur では終わらせない(ドラッグ中に枠の外へフォーカスが移ることがあり、誤って中断してしまう)。
  const LP_WATCHDOG_MS = 5000;
  let lpLastEvent = 0;
  setInterval(() => {
    if (!lpDragging && !lpDown && !rmbDown) return;
    if (Date.now() - lpLastEvent < LP_WATCHDOG_MS) return;
    lpEnd();
  }, 1000);
  window.addEventListener('pointermove', () => { lpLastEvent = Date.now(); }, { capture: true, passive: true });
  window.addEventListener('pointerdown', () => { lpLastEvent = Date.now(); }, { capture: true, passive: true });
  // ドラッグ中はサイト側のスクロール・テキスト選択・長押しメニューを抑止し、離した直後の click も無効化。
  window.addEventListener('touchmove', (e) => {
    if (lpDragging && e.cancelable) e.preventDefault();
  }, { capture: true, passive: false });
  // 長押し待ち中(lpDown)から抑止する。成立(lpDragging)を待つと、待つ間のわずかな移動で先に
  // 選択や選択メニューが始まってしまい、ドラッグ移動後も選択が残る。押している間は選択/メニュー/D&Dを止める。
  // 右クリックは「枠の移動」操作に割り当てたため、枠内では常にブラウザのコンテキストメニューを出さない。
  window.addEventListener('contextmenu', (e) => { e.preventDefault(); }, true);
  // 入力欄の上では抑止しない(contenteditable はキャレットを置く操作自体が選択のため、
  // 抑止すると文字が打てなくなる)。
  window.addEventListener('selectstart', (e) => {
    if ((lpDragging || lpDown) && !isEditable(e.target)) e.preventDefault();
  }, true);
  window.addEventListener('dragstart', (e) => {
    if ((lpDragging || lpDown) && !isEditable(e.target)) e.preventDefault();
  }, true); // リンク/画像のD&D抑止
  window.addEventListener('click', (e) => {
    if (Date.now() - lpEndedAt < 400) { e.preventDefault(); e.stopPropagation(); }
  }, true);

  // ---- 無操作時のカーソル自動非表示を枠(iframe)内にも同期 ----
  // 親(multiview)の body.idle(cursor:none)はトップ文書にしか効かない。枠の上のカーソルは iframe 側の
  // 文書が管理するので、(a) 枠内の操作を tile-activity として親へ中継して「活動中」を伝え(枠の上で動かして
  // いる間はカーソル/≡ を消さない)、(b) 親からの set-idle を受けてこの文書のカーソルを消す/戻す。入れ子へも伝播。
  let idleStyleEl = null;
  const setFrameCursorHidden = (on) => {
    if (on) {
      if (!idleStyleEl) {
        idleStyleEl = document.createElement('style');
        idleStyleEl.textContent = '*, *::before, *::after { cursor: none !important; }';
      }
      if (!idleStyleEl.isConnected) (document.head || document.documentElement).appendChild(idleStyleEl);
    } else if (idleStyleEl && idleStyleEl.isConnected) {
      idleStyleEl.remove();
    }
  };
  let lastActivity = 0;
  const relayActivity = () => {
    setFrameCursorHidden(false); // ローカルでも即カーソルを戻す(往復待ちのチラつき防止)
    const now = Date.now();
    if (now - lastActivity < 400) return; // 中継は間引く(postMessage 連発を防ぐ)
    lastActivity = now;
    post('tile-activity');
  };
  window.addEventListener('pointermove', relayActivity, { capture: true, passive: true });
  window.addEventListener('pointerdown', relayActivity, { capture: true, passive: true });

  // ---- 枠の中のタップを親へ知らせる(枠の選択 + 操作ボタンの表示) ----
  // 枠の中身は別オリジンなので、ここへのタップは親のページに一切届かない。親は「iframe へ
  // フォーカスが移った」を blur で拾っているが、タッチでは移らないことが多く(既にその iframe に
  // フォーカスがある / 動画のタップでフォーカスが動かない)、結果として枠の縁を狙わないと
  // 枠を選べなかった。押した時点で1通だけ送る(移動やスクロールでは送らない=tile-activity とは別)。
  // 入れ子のフレームからも送る。上の階層の content script が親まで中継する。
  window.addEventListener('pointerdown', (e) => {
    if (!e.isPrimary) return;
    post('tile-tap');
  }, { capture: true, passive: true });
  window.addEventListener('message', (e) => {
    if (e.source !== window.parent) return; // この枠を埋め込んでいる親からのみ
    const d = e.data;
    if (!d || d[MAGIC] !== true || d.type !== 'set-idle') return;
    setFrameCursorHidden(d.value === true);
    for (const f of document.querySelectorAll('iframe')) { // 入れ子(YouTube live_chat 等)のカーソルも同期
      try { f.contentWindow.postMessage({ [MAGIC]: true, type: 'set-idle', value: d.value }, '*'); } catch (e2) { /* noop */ }
    }
  });

  // ---- 枠が今開いている URL を親(multiview)へ知らせる ----
  // 直下フレーム(枠本体)からのものだけ親=multiview に届く。枠内で別ページへ移動したら
  // 親が保存し直し、次回その URL を直接復元できる。読込時 + SPA(pushState 等)遷移時に通知。
  function reportUrl() {
    try {
      window.parent.postMessage({ [MAGIC]: true, type: 'frame-url', href: location.href }, '*');
    } catch (e) { /* noop */ }
  }
  reportUrl();
  if (window.navigation && typeof window.navigation.addEventListener === 'function') {
    window.navigation.addEventListener('navigate', () => setTimeout(reportUrl, 0));
  }
  window.addEventListener('popstate', () => setTimeout(reportUrl, 0));
  window.addEventListener('hashchange', () => setTimeout(reportUrl, 0));

  // ---- Twitch のみ: シアターモードにして player を最大化(デスクトップ版サイト専用) ----
  // ※モバイル版にはこのボタンが無い(モバイルは上の枠内シアター 🎭 が担当)。
  // 注意: シアターは「トグル」。Twitch は前回のシアター状態を自前で記憶しているため、再読込時に
  // 既にシアターで開くことがある。そこを無条件に click すると "解除" してしまい、「一瞬シアター→
  // デフォルトに戻る」不具合になる。そこで『まだシアターでない時だけ』1回 click する。
  // 判定: シアター中はトグルボタンの aria-label が「終了 / Exit」系になる(=その時は触らない)。
  if (host.includes('twitch.tv')) {
    const BTN = '[data-a-target="player-theatre-mode-button"], button[aria-label*="シアター"], button[aria-label*="Theatre" i], button[aria-label*="Theater" i]';
    // 起動時に1回だけ: プレイヤーが現れたら、まだデフォルトの時だけシアターへ(既にシアターなら触らない)。
    // ※ SPA遷移ごとの再実行は、シアター切替→プレイヤー再生成→再navigate…のループを招き
    //    配信が激しくカクつくため行わない(ホーム経由のシアター化は別の安全な方法で対応する)。
    let tries = 0;
    const tTimer = setInterval(() => {
      if (tries++ >= 24) { clearInterval(tTimer); return; }
      const btn = document.querySelector(BTN);
      if (!btn) return; // プレイヤー(ボタン)がまだ無い → 次のポーリングへ
      const label = btn.getAttribute('aria-label') || '';
      if (/終了|exit|minimi/i.test(label)) { clearInterval(tTimer); return; } // 既にシアター → 触らない
      btn.click(); // まだデフォルト → シアターへ(1回だけ)
      clearInterval(tTimer);
    }, 500);
  }

  // ---- 埋め込みプレイヤー: サイトへ飛ぶリンクを無効にする ----
  // 埋め込みプレイヤーは映像の上にタイトルやロゴを重ね、それが本サイトへのリンクになっている。
  // 枠を触っているときに踏むと、見ていた枠がサイトへ飛んでしまう。ここは「映像を見る場所」で
  // あって回遊の入口ではないので、飛ばないようにする(元サイトへは ⋮メニューの ↗ で開ける)。
  // クリックを止めるだけでなく、そもそも押せないように見た目からも外す。
  // Twitch のチャットも www.twitch.tv/embed/<ch>/chat = /embed/ 始まりなので、パスだけで
  // 判定するとチャット枠にも入る。隠す指定は一致しないので無害だが、下のリンク無効化が効いて
  // チャット内の URL やメンションが踏めなくなる。プレイヤーの埋め込みだけに絞る。
  const isPlayerEmbed =
    (location.pathname.indexOf('/embed/') === 0 && !/\/chat\/?$/.test(location.pathname)) ||
    host.includes('player.twitch.tv');
  if (isDirectTile && isPlayerEmbed) {
    const st = document.createElement('style');
    st.textContent =
      // YouTube: 上部のタイトル/チャンネル、右下のロゴ、終了画面のリンク。
      // さらに、止まった時に映像を覆うもの: 一時停止中の「他の動画」パネル、終了画面のサムネイル群、
      // エラー画面の中の外部リンク(押すと別タブで YouTube が開く)。
      // エラーの文言自体は残す。枠が黒いだけだと、止まっているのか壊れているのか分からなくなるため。
      '.ytp-title, .ytp-title-channel, .ytp-watermark, .ytp-youtube-button, .ytp-ce-element' +
      ', .ytp-pause-overlay, .ytp-endscreen-content, .ytp-error-content-wrap-reason a, .ytp-small-redirect' +
      // Twitch: プレイヤー上のチャンネル名・タイトル
      ', .player-overlay-background a, [data-a-target="player-info-title-link"]' +
      ' { display: none !important; pointer-events: none !important; }' +
      // Twitch: 再生が止まった時に映像の上へ大きく出る案内(配信タイトル・チャンネル名・カテゴリ)。
      // 回線が細ると出っぱなしになって邪魔なうえ、押すと別タブでサイトが開いてしまう。
      // .video-player__overlay の子のうち、
      //   .player-overlay-background … 再生ボタンが入っている(残す)
      //   .video-preview-overlay      … 停止中のサムネイル(残す)
      //   .click-handler              … タップ判定(残す)
      // 以外を畳む。案内はこのどれでもない子の下にあり、クラス名がビルドごとに変わるハッシュ
      // なので直接は指せない。実機で「案内だけ消えて再生ボタンは残る」ことを確認済み。
      ' .video-player__overlay > div:not(.player-overlay-background):not(.video-preview-overlay):not(.click-handler)' +
      ' { display: none !important; }' +
      // Twitch: 「特定のオーディエンス向けに指定されています」の注意書き(コンテンツ分類ラベル)。
      // 再生ボタンと同じ側にあるので上のルールでは消えない。隠しても再生の妨げにはならないことは
      // 実機で確認済み(隠した状態から再生を再開できた)。
      ' [data-a-target="content-classification-warning-disclosure-overlay"], .disclosure-card' +
      ' { display: none !important; }';
    (document.head || document.documentElement).appendChild(st);
    // 取りこぼし対策。別タブで開く形(target=_blank)も含めて、外へ出るリンクは踏ませない。
    window.addEventListener(
      'click',
      (e) => {
        const a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
        if (!a) return;
        try {
          const u = new URL(a.href, location.href);
          if (u.pathname.indexOf('/embed/') === 0) return; // 埋め込み内で完結する遷移は通す
        } catch (err) { /* noop */ }
        e.preventDefault();
        e.stopPropagation();
      },
      true
    );
  }

  // ---- YouTube の live_chat 枠: チャットが使えるかを親へ知らせる ----
  // ライブでない動画では live_chat が「このライブ ストリームではチャットは無効です。」だけを出す。
  // そのとき DOM は一覧(yt-live-chat-item-list-renderer)を持たず、単独の
  // yt-live-chat-message-renderer だけになる。親は別オリジンで中を見られないので、ここで判定して送る。
  // 判定できるまで少し待つ(読み込み直後はどちらの要素も無い)。
  if (isDirectTile && location.pathname.indexOf('/live_chat') === 0) {
    let tries = 0;
    const timer = setInterval(() => {
      const usable = !!document.querySelector('yt-live-chat-item-list-renderer');
      const dead = !usable && !!document.querySelector('yt-live-chat-message-renderer');
      if (usable || dead) {
        clearInterval(timer);
        post('chat-availability', { ok: usable });
      } else if (++tries > 24) {
        clearInterval(timer); // 12秒待っても判別できない = 触らない(誤って畳まない)
      }
    }, 500);
  }

  // ---- コメント弾幕: チャットDOMを監視して新着コメントを親(multiview)へ送る ----
  // 親からの set-danmaku-enabled で ON/OFF。ON の間だけ MutationObserver でチャットの新着行を拾い、
  // { type:'chat-message', text, author, color } を window.parent へ送る(描画は親=multiview)。
  // YouTube はチャットが入れ子 iframe(live_chat)にあるため、ON は子へ伝播し、コメントは子→親へ中継する。
  // セレクタはサイト更新で変わりうるので複数候補+防御的に(見つからなければ静かに何もしない)。
  const dmkSite =
    host.includes('twitch.tv') ? {
      // sel/containers はライブ + VOD(アーカイブ)両対応。.vod-message と .video-chat__message-list-wrapper が
      // VOD のチャットリプレイ用(twitch.tv/videos/...)。VOD は本文/絵文字/色の内側セレクタをライブと共用するので
      // extractParts/color は変更不要。ライブ用は VOD ページでマッチせず、その逆も同様なので併記で衝突しない。
      sel: '.chat-line__message, [data-a-target="chat-line-message"], .vod-message',
      containers: ['.chat-scrollable-area__message-container', '[data-test-selector="chat-scrollable-area__message-container"]', '.chat-list--default', '.video-chat__message-list-wrapper', '[data-test-selector="video-chat-message-list-wrapper"]'],
      // ライブの綺麗な表示名(.chat-author__display-name)を最優先。無い時だけ VOD 専用の著者ラッパへフォールバック。
      // ※ querySelector の複数指定は「文書順で最初」を返すため、ラッパが先に来ないよう || で順序を明示する。
      author: (n) => n.querySelector('.chat-author__display-name, [data-a-target="chat-message-username"]') || n.querySelector('.video-chat__message-author, [data-test-selector="comment-author-selector"]'),
      // 本文 = テキスト断片 + 絵文字/スタンプ(emote img)を出現順に parts 化。スタンプは画像として親へ渡す。
      // テキスト断片 + 行内の非バッジ img(絵文字/スタンプ/ビッツ)を出現順に。emote のクラス名変更にも強い。
      extractParts: (n) => {
        const parts = [];
        n.querySelectorAll('[data-a-target="chat-message-text"], img:not(.chat-badge)').forEach((p) => {
          if (p.tagName === 'IMG') parts.push({ img: p.currentSrc || p.src || '', alt: p.getAttribute('alt') || '' });
          else { const t = (p.textContent || '').replace(/\s+/g, ' '); if (t.trim()) parts.push({ text: t }); }
        });
        return parts;
      },
      color: (n) => { const a = n.querySelector('.chat-author__display-name'); return a ? a.style.color : ''; }
    } :
    host.includes('youtube.com') ? {
      sel: 'yt-live-chat-text-message-renderer, yt-live-chat-paid-message-renderer',
      containers: ['yt-live-chat-item-list-renderer #items', '#items.yt-live-chat-item-list-renderer'],
      author: (n) => n.querySelector('#author-name'),
      text: (n) => n.querySelector('#message'),
      color: () => ''
    } :
    (host.includes('mellow-fan.com') || host.includes('openrec.tv')) ? {
      // mellow-fan(旧 OPENREC)。改名後も URL 形式とチャットのコンテナ(.chat-list-content)は同じだが、
      // 行のクラスは .or-chat-article なので、旧 .chat-content では1件も拾えない(実機で確認)。
      sel: '.or-chat-article, [class*="ChatArticle__Wrapper"], .chat-content, [class*="chat-content"]',
      containers: ['.chat-list-content', '[class*="ChatList__Content"]', '.chat-list'],
      author: (n) => n.querySelector('[class*="user-name"], [class*="userName"]'),
      text: (n) => n.querySelector('[class*="message"], [class*="Message"], [class*="comment"]'),
      color: () => ''
    } :
    host.includes('kick.com') ? {
      // Kick(popout チャット)。行に固定のクラスが無く、付いているのは Tailwind のユーティリティだけ
      // なので、実測した構造から拾う(2026-08 時点):
      //   #chatroom-messages > (仮想リストの入れ物) > div.…px-2…   ← これが1行
      //     span(時刻) / button[data-prevent-expand](投稿者。色は style に入る) / span.…font-normal…(本文)
      // 一覧の入れ物 #chatroom-messages は id なので、ここが変わらない限り追従できる。
      // 時刻は font-semibold、区切りの「:」は font-bold なので、本文だけが font-normal で拾える。
      sel: 'div[class*="px-2"]',
      containers: ['#chatroom-messages'],
      author: (n) => n.querySelector('button[data-prevent-expand]'),
      text: (n) => n.querySelector('span[class*="font-normal"]'),
      color: (n) => { const a = n.querySelector('button[data-prevent-expand]'); return a ? a.style.color : ''; }
    } : null;

  let dmkOn = false;
  let dmkObserver = null;
  let dmkContainer = null;
  let dmkSent = 0, dmkWindowStart = 0;
  const DMK_RATE = 40; // 1秒あたりの送信上限(高頻度チャットでの暴発抑制)

  // 要素内をテキスト/絵文字に分解して parts 配列で返す(出現順)。各要素は {text} か {img,alt}。
  // 絵文字/スタンプは画像として親へ渡す(親が <img> で描画)。Twitch のバッジ(chat-badge)は除外。
  function dmkPartsFromEl(el) {
    if (!el) return [];
    const parts = [];
    let buf = '';
    const flush = () => { const t = buf.replace(/\s+/g, ' '); if (t.trim()) parts.push({ text: t }); buf = ''; };
    (function walk(n) {
      for (const c of n.childNodes) {
        if (c.nodeType === 3) buf += c.nodeValue;                 // テキストノード
        else if (c.nodeType === 1) {
          if (c.tagName === 'IMG') {                              // 絵文字/スタンプ(バッジは除外)
            if (!c.classList.contains('chat-badge')) { flush(); parts.push({ img: c.currentSrc || c.src || '', alt: c.getAttribute('alt') || '' }); }
          } else walk(c);
        }
      }
    })(el);
    flush();
    return parts;
  }
  // parts を安全化: https の画像のみ・枚数/文字数/セグメント数の上限・空除去。
  function dmkCleanParts(parts) {
    const out = [];
    let textLen = 0, imgs = 0;
    for (const p of (parts || [])) {
      if (p && p.img) {
        if (imgs >= 24 || !/^https:\/\//i.test(String(p.img))) continue; // 絵文字画像は https のみ・最大24個
        out.push({ img: String(p.img).slice(0, 500), alt: String(p.alt || '').slice(0, 40) });
        imgs++;
      } else if (p && p.text != null) {
        let t = String(p.text);
        if (textLen + t.length > 200) t = t.slice(0, 200 - textLen);
        if (t) { out.push({ text: t }); textLen += t.length; }
      }
      if (out.length >= 60) break;
    }
    return out;
  }
  function dmkSend(line) {
    if (!dmkSite) return;
    try {
      const aEl = dmkSite.author(line);
      const author = aEl ? (aEl.textContent || '').trim().slice(0, 40) : '';
      let parts;
      if (dmkSite.extractParts) {
        parts = dmkSite.extractParts(line); // サイト専用(テキスト+絵文字画像。Twitch)
      } else {
        const textEl = dmkSite.text(line);
        parts = dmkPartsFromEl(textEl || line); // 専用本文要素を分解(YouTube #message 等。絵文字画像込み)
        if (!textEl && author && parts.length && parts[0].text) {
          // フォールバック(行全体を読んだ時): 先頭の著者名を取り除く
          const t = parts[0].text.replace(/^\s+/, '');
          if (t.startsWith(author)) parts[0].text = t.slice(author.length);
        }
      }
      parts = dmkCleanParts(parts);
      if (!parts.length) return;
      let color = '';
      try { color = dmkSite.color(line) || ''; } catch (e) { /* noop */ }
      const now = Date.now();
      if (now - dmkWindowStart > 1000) { dmkWindowStart = now; dmkSent = 0; }
      if (dmkSent >= DMK_RATE) return; // 一気に大量に来たら間引く
      dmkSent++;
      window.parent.postMessage({ [MAGIC]: true, type: 'chat-message', parts, author, color, ts: now }, '*');
    } catch (e) { /* noop */ }
  }
  function dmkProcessNode(node) {
    if (!dmkSite || !node || node.nodeType !== 1) return;
    if (node.matches && node.matches(dmkSite.sel)) dmkSend(node);
    else if (node.querySelectorAll) node.querySelectorAll(dmkSite.sel).forEach(dmkSend);
  }
  function dmkAttach(container) {
    if (dmkObserver) dmkObserver.disconnect();
    dmkObserver = new MutationObserver((muts) => {
      for (const m of muts) for (const n of m.addedNodes) dmkProcessNode(n);
    });
    // subtree:true は VOD(アーカイブ)対応で必須。VOD のチャットリプレイは新着行を wrapper 直下ではなく
    // ネストした <ul> に追加する(間に <div> が挟まることもある)ため、childList だけだと取りこぼす。
    // dmkProcessNode は sel に一致するノードだけ送るので、内部の遅延ロード(絵文字 img 等)で多重送信はしない。
    dmkObserver.observe(container, { childList: true, subtree: true });
  }
  // 入れ子チャット(現状 YouTube の live_chat)を持つ子 iframe にだけ ON/OFF を伝える。広告/第三者 iframe には
  // 送らず、targetOrigin も YouTube に固定。ON 中は dmkTick から毎周期呼び、遅延ロードの live_chat も取りこぼさない。
  function dmkBroadcastChildren() {
    if (!host.includes('youtube.com')) return; // 入れ子チャットを持つのは現状 YouTube のみ
    const frames = document.querySelectorAll('iframe#chatframe, iframe[src*="/live_chat"]');
    for (const f of frames) {
      try { f.contentWindow.postMessage({ [MAGIC]: true, type: 'set-danmaku-enabled', value: dmkOn }, 'https://www.youtube.com'); } catch (e) { /* noop */ }
    }
  }
  // チャット欄が見つかっているかを親へ知らせる。サイトの DOM が変わってセレクタが古くなると
  // 弾幕は「ONにしたのに何も流れない」状態になるが、それが故障なのかチャットが過疎なだけなのかを
  // 利用者もコードも区別できなかった。見つからない状態が続いたら報告して枠バッジに出す。
  let dmkReported = null;
  let dmkMissTicks = 0;
  const DMK_MISS_LIMIT = 7; // 1.5秒 × 7 ≒ 10秒。読み込みの遅れでは鳴らないだけの余裕を取る
  function reportDanmaku(state) {
    if (dmkReported === state) return;
    dmkReported = state;
    try {
      window.parent.postMessage({ [MAGIC]: true, type: 'danmaku-state', state }, '*');
    } catch (e) { /* noop */ }
  }

  function dmkTick() {
    if (!dmkSite) return;
    if (!dmkOn) {
      if (dmkObserver) { dmkObserver.disconnect(); dmkObserver = null; }
      dmkContainer = null;
      dmkMissTicks = 0;
      reportDanmaku('off');
      return;
    }
    dmkBroadcastChildren(); // ON中は毎周期、遅れて出てくる live_chat 子へも value:true を送り直す(取りこぼし対策)
    if (dmkContainer && dmkContainer.isConnected) { dmkMissTicks = 0; reportDanmaku('on'); return; } // 監視中
    for (const sel of dmkSite.containers) {
      const c = document.querySelector(sel);
      if (c) { dmkContainer = c; dmkAttach(c); break; } // SPA再生成にもこのポーリングで張り直す
    }
    if (dmkContainer) { dmkMissTicks = 0; reportDanmaku('on'); }
    else if (++dmkMissTicks >= DMK_MISS_LIMIT) reportDanmaku('missing');
  }
  // 親から呼ばれる(set-danmaku-enabled)。自分の監視を ON/OFF し、入れ子チャットの子へも伝播する。
  function danmakuSetEnabled(on) {
    dmkOn = !!on;
    dmkTick();
    dmkBroadcastChildren(); // OFF も即時伝播(dmkTick は OFF だと早期 return するため)
  }
  if (dmkSite) setInterval(dmkTick, 1500);

  // 入れ子フレーム連携: 子からの chat-message は親へ中継し、子の frame-hello には現在の弾幕状態を返す
  // (子の読込が遅れても取りこぼさない)。親からの下り(set-*)は上の本体リスナが処理する。
  // 中継を許可するのは対象サイト配下のフレームのみ(YouTube live_chat 等)。第三者/広告 iframe からの偽装を弾く。
  const DMK_RELAY_HOSTS = ['twitch.tv', 'youtube.com', 'openrec.tv', 'mellow-fan.com'];
  function dmkOriginAllowed(origin) {
    try { const h = new URL(origin).hostname; return DMK_RELAY_HOSTS.some((d) => h === d || h.endsWith('.' + d)); }
    catch (e) { return false; }
  }
  window.addEventListener('message', (e) => {
    if (e.source === window.parent) return;   // 子フレームからのメッセージだけ扱う
    if (!dmkOriginAllowed(e.origin)) return;  // 対象サイト配下の子のみ(広告/第三者iframeを弾く)
    const d = e.data;
    if (!d || d[MAGIC] !== true) return;
    if (d.type === 'tile-activity' || d.type === 'tile-tap') { // 入れ子(live_chat 等)の操作も上(最終的にトップ)へ中継
      try { window.parent.postMessage(d, '*'); } catch (err) { /* noop */ }
    } else if (d.type === 'chat-message') {
      if (!dmkOn) return; // ON の間だけ中継(不要中継・注入面の縮小)
      try { window.parent.postMessage(d, '*'); } catch (err) { /* noop */ }
    } else if (d.type === 'frame-hello') {
      try { e.source.postMessage({ [MAGIC]: true, type: 'set-danmaku-enabled', value: dmkOn }, e.origin || '*'); } catch (err) { /* noop */ }
    }
  });
})();
